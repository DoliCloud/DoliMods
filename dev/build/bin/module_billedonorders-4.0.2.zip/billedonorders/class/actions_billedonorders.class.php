<?php
/* Copyright (C) 2011-2013	Laurent Destailleur	<eldy@users.sourceforge.net>
 * Copyright (C) 2012		Regis Houssin		<regis.houssin@capnetworks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *	\file       htdocs/billedonorders/class/actions_billedonorders.class.php
 *	\ingroup    billedonorders
 *	\brief      File to control actions
 */
require_once DOL_DOCUMENT_ROOT."/core/class/commonobject.class.php";


/**
 *	Class to manage hooks for module BilledOnOrders
 */
class ActionsBilledOnOrders
{
	public $db;
	public $error;
	public $errors=array();

	/**
	 *	Constructor
	 *
	 *  @param		DoliDB		$db      Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * Complete array of fields for list
	 *
	 * @param	array	$parameters		Array of parameters
	 * @param	object	$object			Object
	 * @param	string	$action			Action
	 * @param	hookmanager	$hookmanager	Hook manager
	 * @return	array				Array of fields to add
	 */
	public function completeArrayFields($parameters, &$object, &$action, $hookmanager)
	{
		global $langs;

		$mode = 'old';

		if ($mode != 'old') {
			if (in_array('orderlist', explode(':', $parameters['context'])) || in_array('supplierorderlist', explode(':', $parameters['context']))) {
				$langs->load("billedonorders@billedonorders");

				$parameters['arrayfields']['billedonorders.billedht'] = array(
					'label'=>$langs->transnoentitiesnoconv("AmountBilledHT"),
					'checked'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_BILLEDWOTAX') ? 0 : 1),
					'position'=>100,
					'enabled'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_BILLEDWOTAX') ? 0 : 1)
				);
				$parameters['arrayfields']['billedonorders.billedttc'] = array(
					'label'=>$langs->transnoentitiesnoconv("AmountBilledTTC"),
					'checked'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_BILLED') ? 0 : 1),
					'position'=>101,
					'enabled'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_BILLED') ? 0 : 1)
				);
				$parameters['arrayfields']['billedonorders.paid'] = array(
					'label'=>$langs->transnoentitiesnoconv("AlreadyPaid"),
					'checked'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_PAYED') ? 0 : 1),
					'position'=>102,
					'enabled'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_PAYED') ? 0 : 1)
				);
				$parameters['arrayfields']['billedonorders.remaintopay'] = array(
					'label'=>$langs->transnoentitiesnoconv("RemainderToPay"),
					'checked'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOPAY') ? 0 : 1),
					'position'=>103,
					'enabled'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOPAY') ? 0 : 1)
				);
				$parameters['arrayfields']['billedonorders.remaintobillexcltax'] = array(
					'label'=>$langs->transnoentitiesnoconv("RemainderToBillExclTax"),
					'checked'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX') ? 0 : 1),
					'position'=>104,
					'enabled'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX') ? 0 : 1)
				);
				$parameters['arrayfields']['billedonorders.remaintobill'] = array(
					'label'=>$langs->transnoentitiesnoconv("RemainderToBillTTC"),
					'checked'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILL') ? 0 : 1),
					'position'=>105,
					'enabled'=>(getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILL') ? 0 : 1)
				);
			}
		}
		return 0;
	}

	/**
	 * Add a column in some list
	 *
	 * @param	array	$parameters		Array of parameters
	 * @param	object	$object			Object
	 * @return	string					HTML content to add by hook
	 */
	public function printFieldListTitle($parameters, &$object)
	{
		global $langs;
		global $param, $sortfield, $sortorder;

		$mode = 'old';
		if ($mode == 'old') {
			if ($parameters['currentcontext'] == 'orderlist') {
				$langs->load("billedonorders@billedonorders");
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLEDWOTAX'))
				print_liste_field_titre($langs->transnoentitiesnoconv("AmountBilledHT"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLED'))
				print_liste_field_titre($langs->transnoentitiesnoconv("AmountBilledTTC"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_PAYED'))
				print_liste_field_titre($langs->transnoentitiesnoconv("AlreadyPaid"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOPAY'))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToPay"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ', 'AmongAlreadyCreatedInvoices::-1');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX'))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToBillExclTax"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ', '');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILL'))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToBillTTC"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
			}
			if ($parameters['currentcontext'] == 'supplierorderlist') {
				$langs->load("billedonorders@billedonorders");
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLEDWOTAX'))
				print_liste_field_titre($langs->transnoentitiesnoconv("AmountBilledHT"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLED'))
				print_liste_field_titre($langs->transnoentitiesnoconv("AmountBilledTTC"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_PAYED'))
				print_liste_field_titre($langs->transnoentitiesnoconv("AlreadyPaid"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOPAY'))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToPay"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ', 'AmongAlreadyCreatedInvoices::-1');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX'))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToBillExclTax"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ', '');
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILL'))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToBillTTC"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
			}
		} else {
			// Check if fields are selected
			$selectedfields = is_array($parameters['selectedfields']) ? $parameters['selectedfields'] : array();

			if (in_array('orderlist', explode(':', $parameters['context']))) {
				$langs->load("billedonorders@billedonorders");
				if (in_array('billedonorders.billedht', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("AmountBilledHT"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (in_array('billedonorders.billedttc', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("AmountBilledTTC"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (in_array('billedonorders.paid', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("AlreadyPaid"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (in_array('billedonorders.remaintopay', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToPay"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ', 'AmongAlreadyCreatedInvoices::-1');
				if (in_array('billedonorders.remaintobillexcltax', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToBillExclTax"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ', '');
				if (in_array('billedonorders.remaintobill', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToBillTTC"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
			}
			if (in_array('supplierorderlist', explode(':', $parameters['context']))) {
				$langs->load("billedonorders@billedonorders");
				if (in_array('billedonorders.billedht', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("AmountBilledHT"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (in_array('billedonorders.billedttc', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("AmountBilledTTC"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (in_array('billedonorders.paid', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("AlreadyPaid"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
				if (in_array('billedonorders.remaintopay', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToPay"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ', 'AmongAlreadyCreatedInvoices::-1');
				if (in_array('billedonorders.remaintobillexcltax', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToBillExclTax"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ', '');
				if (in_array('billedonorders.remaintobill', $selectedfields))
				print_liste_field_titre($langs->transnoentitiesnoconv("RemainderToBillTTC"), $_SERVER["PHP_SELF"], '', '', $param, '', $sortfield, $sortorder, 'right ');
			}
		}

		return 0;
	}

	/**
	 * Add a column in some list
	 *
	 * @param	array	$parameters		Array of parameters
	 * @param	object	$object			Object
	 * @return	string					HTML content to add by hook
	 */
	public function printFieldListOption($parameters, &$object)
	{
		$mode = 'old';
		if ($mode == 'old') {
			if ($parameters['currentcontext'] == 'orderlist') {
				//global $param, $sortfield, $sortorder;
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLEDWOTAX')) {
					//print '<td align="right"><input type="text" name="billedonorders_billed" style="max-width:50px" class="flat maxwidth50" value="'.GETPOST('billedonorders_billed').'"></td>';
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLED')) {
					//print '<td align="right"><input type="text" name="billedonorders_billed" style="max-width:50px" class="flat maxwidth50" value="'.GETPOST('billedonorders_billed').'"></td>';
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_PAYED')) {
					//print '<td align="right"><input type="text" name="billedonorders_payed" style="max-width:50px" class="flat maxwidth50" value="'.GETPOST('billedonorders_payed').'"></td>';
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOPAY')) {
					//print '<td align="right"><input type="text" name="billedonorders_remaintopay" style="max-width:50px" class="flat maxwidth50" value="'.GETPOST('billedonorders_remaintopay').'"></td>';
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX')) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILL')) {
					print '<td class="liste_titre" align="right"></td>';
				}
			}

			if ($parameters['currentcontext'] == 'supplierorderlist') {
				//global $param, $sortfield, $sortorder;
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLEDWOTAX')) {
					//print '<td align="right"><input type="text" name="billedonorders_billed" style="max-width:50px" class="flat maxwidth50" value="'.GETPOST('billedonorders_billed').'"></td>';
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLED')) {
					//print '<td align="right"><input type="text" name="billedonorders_billed" style="max-width:50px" class="flat maxwidth50" value="'.GETPOST('billedonorders_billed').'"></td>';
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_PAYED')) {
					//print '<td align="right"><input type="text" name="billedonorders_payed" style="max-width:50px" class="flat maxwidth50" value="'.GETPOST('billedonorders_payed').'"></td>';
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOPAY')) {
					//print '<td align="right"><input type="text" name="billedonorders_remaintopay" style="max-width:50px" class="flat maxwidth50" value="'.GETPOST('billedonorders_remaintopay').'"></td>';
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX')) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILL')) {
					print '<td class="liste_titre" align="right"></td>';
				}
			}
		} else {
			// Check if fields are selected
			$selectedfields = is_array($parameters['selectedfields']) ? $parameters['selectedfields'] : array();

			if (in_array('orderlist', explode(':', $parameters['context']))) {
				if (in_array('billedonorders.billedht', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.billedttc', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.paid', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.remaintopay', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.remaintobillexcltax', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.remaintobill', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
			}

			if (in_array('supplierorderlist', explode(':', $parameters['context']))) {
				if (in_array('billedonorders.billedht', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.billedttc', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.paid', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.remaintopayexcltax', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.remaintopay', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.remaintobillexcltax', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
				if (in_array('billedonorders.remaintobill', $selectedfields)) {
					print '<td class="liste_titre" align="right"></td>';
				}
			}
		}

		return 0;
	}

	/**
	 * Add a column in some list
	 *
	 * @param	array	$parameters		Array of parameters
	 * @param	object	$object			Object
	 * @return	string					HTML content to add by hook
	 */
	public function printFieldListValue($parameters, &$object)
	{
		global $langs;
		global $db;
		//global $param, $sortfield, $sortorder;

		// Check if fields are selected
		//$selectedfields = is_array($parameters['selectedfields']) ? $parameters['selectedfields'] : array();

		if ($parameters['currentcontext'] == 'orderlist') {
			global $ordertmpforloop;
			if (! is_object($ordertmpforloop)) {
				$ordertmpforloop = new Commande($db);
			}
			global $invoicetmpforloop;
			if (! is_object($invoicetmpforloop)) {
				include_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
				$invoicetmpforloop = new Facture($db);
			}

			$billedht=0;
			$billedttc=0;
			$paid=0;
			$remaintopay=0;
			$remaintobillexcltax=0;
			$remaintobill=0;
			//$warning='';  TODO Check if invoice is used for more than one order
			if (is_object($parameters['obj'])) {
				$id = $parameters['obj']->rowid ? $parameters['obj']->rowid : $parameters['obj']->id;
				if ($id > 0) {
					$ordertmpforloop->fetch($id);
					$ordertmpforloop->fetchObjectLinked($id, 'commande', 0, 'facture');
					$linkedobj1 = $ordertmpforloop->linkedObjectsIds;
					$ordertmpforloop->fetchObjectLinked(0, 'facture', $id, 'commande');
					$linkedobj2 = $ordertmpforloop->linkedObjectsIds;
					// We must not use array_merge because the 2 arrays have key 'facture' and the second one will overwrite the first one.
					$linkedobj = array_merge_recursive($linkedobj1, $linkedobj2);
					//var_dump($linkedobj);
				}
			}
			foreach ($linkedobj as $types) {
				foreach ($types as $val) {
					//var_dump($val);
					$result = $invoicetmpforloop->fetch($val);
					if ($result > 0) {
						if ($invoicetmpforloop->status != $invoicetmpforloop::STATUS_DRAFT && $invoicetmpforloop->status != $invoicetmpforloop::STATUS_ABANDONED) {
							$billedht += $invoicetmpforloop->total_ht;
							$billedttc += $invoicetmpforloop->total_ttc;
							$paymentarray = $invoicetmpforloop->getListOfPayments();
							foreach ($paymentarray as $val2) {
								//var_dump($val2);
								$paid += $val2['amount'];
							}
						}
					} else {
						dol_print_error($db);
					}
				}
			}
			$remaintopay = price2num($billedttc - $paid, 'MT');
			$remaintobillexcltax = price2num($parameters['obj']->total_ht - $billedht, 'MT');
			$remaintobill = price2num($parameters['obj']->total_ttc - $billedttc, 'MT');

			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLEDWOTAX')) {
				print '<td class="right nowraponall">'.($billedht ? price($billedht) : '');
				if ($billedht && $parameters['obj']->total_ht != $billedht) {
					print img_warning($langs->trans("AmountBilledDiffersFromAmountOnOrder"));
				}
				print '</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) {
					// Warning, some module may break position of total (like multicompany)
					$totalarray['nbfield']++;
					if (getDolGlobalString('BILLEDONORDERS_SHOW_TOTAL')) {
						$totalarray['pos'][$totalarray['nbfield']] = 'BILLEDONORDERS_DISABLE_BILLEDWOTAX';
					}
					$totalarray['val']['BILLEDONORDERS_DISABLE_BILLEDWOTAX'] = 0;
				}
				$totalarray['val']['BILLEDONORDERS_DISABLE_BILLEDWOTAX'] += $billedht;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLED')) {
				print '<td class="right nowraponall">'.($billedttc?price($billedttc):'');
				if ($billedttc && $parameters['obj']->total_ttc != $billedttc) {
					print img_warning($langs->trans("AmountBilledDiffersFromAmountOnOrder"));
				}
				print '</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) {
					$totalarray['nbfield']++;
					if (getDolGlobalString('BILLEDONORDERS_SHOW_TOTAL')) {
						$totalarray['pos'][$totalarray['nbfield']] = 'BILLEDONORDERS_DISABLE_BILLED';
					}
					$totalarray['val']['BILLEDONORDERS_DISABLE_BILLED'] = 0;
				}
				$totalarray['val']['BILLEDONORDERS_DISABLE_BILLED'] += $billedttc;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_PAYED')) {
				print '<td class="right nowraponall">'.($paid?price($paid):'').'</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) {
					$totalarray['nbfield']++;
					if (getDolGlobalString('BILLEDONORDERS_SHOW_TOTAL')) {
						$totalarray['pos'][$totalarray['nbfield']] = 'BILLEDONORDERS_DISABLE_PAYED';
					}
					$totalarray['val']['BILLEDONORDERS_DISABLE_PAYED'] = 0;
				}
				$totalarray['val']['BILLEDONORDERS_DISABLE_PAYED'] += $paid;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOPAY')) {
				print '<td class="right nowraponall">'.($remaintopay?price($remaintopay):'').'</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) {
					$totalarray['nbfield']++;
					if (getDolGlobalString('BILLEDONORDERS_SHOW_TOTAL')) {
						$totalarray['pos'][$totalarray['nbfield']] = 'BILLEDONORDERS_DISABLE_REMAINTOPAY';
					}
					$totalarray['val']['BILLEDONORDERS_DISABLE_REMAINTOPAY'] = 0;
				}
				$totalarray['val']['BILLEDONORDERS_DISABLE_REMAINTOPAY'] += $remaintopay;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX')) {
				print '<td class="right nowraponall">'.($remaintobillexcltax?price($remaintobillexcltax):'').'</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) {
					$totalarray['nbfield']++;
					if (getDolGlobalString('BILLEDONORDERS_SHOW_TOTAL')) {
						$totalarray['pos'][$totalarray['nbfield']] = 'BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX';
					}
					$totalarray['val']['BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX'] = 0;
				}
				$totalarray['val']['BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX'] += $remaintobillexcltax;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILL')) {
				print '<td class="right nowraponall">'.($remaintobill?price($remaintobill):'').'</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) {
					$totalarray['nbfield']++;
					if (getDolGlobalString('BILLEDONORDERS_SHOW_TOTAL')) {
						$totalarray['pos'][$totalarray['nbfield']] = 'BILLEDONORDERS_DISABLE_REMAINTOBILL';
					}
					$totalarray['val']['BILLEDONORDERS_DISABLE_REMAINTOBILL'] = 0;
				}
				$totalarray['val']['BILLEDONORDERS_DISABLE_REMAINTOBILL'] += $remaintobill;
			}
		}

		if ($parameters['currentcontext'] == 'supplierorderlist') {
			global $ordertmpforloop;
			if (! is_object($ordertmpforloop)) {
				$ordertmpforloop = new CommandeFournisseur($db);
			}
			global $invoicetmpforloop;
			if (! is_object($invoicetmpforloop)) {
				include_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.class.php';
				$invoicetmpforloop = new FactureFournisseur($db);
			}

			$billedht=0;
			$billedttc=0;
			$paid=0;
			$remaintopay=0;
			$remaintobillexcltax=0;
			$remaintobill=0;
			//$warning='';  TODO Check if invoice is used for more than one order
			if (is_object($parameters['obj'])) {
				$id = $parameters['obj']->rowid ? $parameters['obj']->rowid : $parameters['obj']->id;
				if ($id > 0) {
					$ordertmpforloop->fetch($id);
					$ordertmpforloop->fetchObjectLinked($id, 'order_supplier', 0, 'invoice_supplier');
					$linkedobj1 = $ordertmpforloop->linkedObjectsIds;
					$ordertmpforloop->fetchObjectLinked(0, 'invoice_supplier', $id, 'order_supplier');
					$linkedobj2 = $ordertmpforloop->linkedObjectsIds;
					// We must not use array_merge because the 2 arrays have key 'invoice_supplier' and the second one will overwrite the first one.
					$linkedobj = array_merge_recursive($linkedobj1, $linkedobj2);
					//var_dump($linkedobj);
				}
			}
			foreach ($linkedobj as $types) {
				foreach ($types as $val) {
					//var_dump($val);
					$result = $invoicetmpforloop->fetch($val);
					if ($result > 0) {
						if ($invoicetmpforloop->status != $invoicetmpforloop::STATUS_DRAFT && $invoicetmpforloop->status != $invoicetmpforloop::STATUS_ABANDONED) {
							$billedht += $invoicetmpforloop->total_ht;
							$billedttc += $invoicetmpforloop->total_ttc;
							if (method_exists($invoicetmpforloop, 'getListOfPayments')) {
								$paymentarray = $invoicetmpforloop->getListOfPayments();
								foreach ($paymentarray as $val2) {
									//var_dump($val2);
									$paid += $val2['amount'];
								}
							}
						}
					} else {
						dol_print_error($db);
					}
				}
			}
			$remaintopay = price2num($billedttc - $paid, 'MT');
			$remaintobillexcltax = price2num($parameters['obj']->total_ht - $billedht, 'MT');
			$remaintobill = price2num($parameters['obj']->total_ttc - $billedttc, 'MT');

			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLEDWOTAX')) {
				print '<td class="right nowraponall">'.($billedht?price($billedht):'');
				if ($billedht && $parameters['obj']->total_ht != $billedht) {
					print img_warning($langs->trans("AmountBilledDiffersFromAmountOnOrder"));
				}
				print '</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) $totalarray['nbfield']++;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_BILLED')) {
				print '<td class="right nowraponall">'.($billedttc?price($billedttc):'');
				if ($billedttc && $parameters['obj']->total_ttc != $billedttc) {
					print img_warning($langs->trans("AmountBilledDiffersFromAmountOnOrder"));
				}
				print '</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) $totalarray['nbfield']++;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_PAYED')) {
				print '<td class="right nowraponall">';
				if (method_exists($invoicetmpforloop, 'getListOfPayments')) print ($paid?price($paid):'');
				else print 'AvailableWithv7.0.1+';
				print '</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) $totalarray['nbfield']++;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOPAY')) {
				print '<td class="right nowraponall">';
				if (method_exists($invoicetmpforloop, 'getListOfPayments')) print ($remaintopay?price($remaintopay):'');
				else print 'AvailableWithv7.0.1+';
				print '</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) $totalarray['nbfield']++;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILLEXCLTAX')) {
				print '<td class="right nowraponall">';
				print ($remaintobillexcltax?price($remaintobillexcltax):'');
				print '</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) $totalarray['nbfield']++;
			}
			if (!getDolGlobalString('BILLEDONORDERS_DISABLE_REMAINTOBILL')) {
				print '<td class="right nowraponall">';
				print ($remaintobill?price($remaintobill):'');
				print '</td>';
				global $totalarray;
				if (isset($parameters['i']) && ! $parameters['i']) $totalarray['nbfield']++;
			}
		}

		return 0;
	}
}
