# ChangeLog SCANNER MODULE FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>


## 1.0

Initial version.
