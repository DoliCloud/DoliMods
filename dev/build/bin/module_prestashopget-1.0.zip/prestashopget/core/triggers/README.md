Directory where triggers files are stored.
